/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# "Insert system clock initialization code here" comment
 * -# Minimal main function that starts with a call to board_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include "wifi.h"
#include "camera.h"
#include "ov2640.h"
#include "timer_interface.h"
uint8_t aaa;

int main (void)
{
// 	sysclk_init();
// 	wdt_disable(WDT);
// 	board_init();
// 	init_camera();
// 	
// 	aaa = start_capture();
	
	
	/* Initialize clock and board definitions */
	sysclk_init();
	wdt_disable(WDT);
	board_init();
	
	/* Configure and start the Timer */
	configure_tc();
	
	/* Configure the WiFi USART and SPI, as well as the ��command complete�� and ��provision�� pins */
	configure_usart_wifi();
	spi_peripheral_initialize();
	configure_spi();
	configure_wifi_provision_pin();
	configure_wifi_comm_pin();
	
	/* Configure LED indicators */
	write_wifi_command("set wlan_gpio 25\r\n", 3);
	write_wifi_command("set websocket_gpio 26\r\n", 3);
	write_wifi_command("set ap_gpio 27\r\n", 3);
	
	/* Configure ��command complete��, ��network��, and ��clients�� GPIOs */
	write_wifi_command("set net_gpio 21\r\n", 3);
	write_wifi_command("set clients_gpio 22\r\n", 3);
	write_wifi_command("set comm_gpio 32\r\n", 3);
	
	/* Initialize and configure the camera */
	init_camera();
	
	/* Reset the WiFi and wait for it to connect to a network */
	/* Send ��test�� to the WiFi module and wait for a response of ��SUCCESS�� */
	g_b_prov_button = false;
	g_b_success_received = false;
	ioport_toggle_pin_level(WIFI_RESET);
	delay_ms(50);
	ioport_toggle_pin_level(WIFI_RESET);
	while (!ioport_get_pin_level(WIFI_NETWORK)){
		if (g_b_prov_button == true) {
			write_wifi_command("provision\r\n", 1);
			g_b_prov_button = false;
		}
	}
	while (!g_b_success_received) {
		write_wifi_command("test\r\n", 10);
	}
	g_b_success_received = false;
	
	while (!g_b_success_received) {

					if (g_b_prov_button) {
						write_wifi_command("provision\r\n", 1);
						g_b_prov_button = false;
/*					}*/
				}
		write_wifi_command("test\r\n", 10);
	}
	
	/* Main loop */
	while (1) {
		//write_wifi_command("provision\r\n", 1);
		/* Check for provisioning request and act accordingly */
		if (g_b_prov_button) {
			write_wifi_command("provision\r\n", 1);
			g_b_prov_button = false;
		}
		
		/* If network is available and clients are connected, take picture */
		if (ioport_get_pin_level(WIFI_NETWORK) && ioport_get_pin_level(WIFI_CLIENTS)) {
			if (start_capture()) {
				write_image_to_web();
			}
		}
	}

}