/*
 * init.c
 *
 * Created: 2/22/2023 3:54:05 PM
 *  Author: ece-lab3
 */ 

