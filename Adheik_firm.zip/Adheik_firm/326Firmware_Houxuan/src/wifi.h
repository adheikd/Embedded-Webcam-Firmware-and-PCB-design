/*
 * wifi.h
 *
 * Created: 2023/2/19 14:15:12
 *  Author: AlanG
 */ 
#include <asf.h>
#include <string.h>
#include <stdio.h>
#include "timer_interface.h"

#ifndef WIFI_H_
#define WIFI_H_

#define BOARD_ID_USART             ID_USART0
#define BOARD_USART                USART0
#define BOARD_USART_BAUDRATE       115200
#define wifi_usart_handler         USART0_Handler
#define USART_IRQn                 USART0_IRQn

#define ALL_INTERRUPT_MASK  0xffffffff

/** USART0 pin RX */
#define PIN_USART0_RXD			  {PIO_PA5A_RXD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_PULLUP}
#define PIN_USART0_RXD_IDX        (PIO_PA5_IDX)
#define PIN_USART0_RXD_FLAGS      (PIO_PERIPH_A | PIO_PULLUP)
/** USART0 pin TX */
#define PIN_USART0_TXD			  {PIO_PA6A_TXD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_PULLUP}
#define PIN_USART0_TXD_IDX        (PIO_PA6_IDX)
#define PIN_USART0_TXD_FLAGS      (PIO_PERIPH_A | PIO_PULLUP)

#define WIFI_COMM_PIN_NUM			PIO_PB14
#define WIFI_COMM_PIO				PIOB
#define WIFI_COMM_ID				ID_PIOB
#define WIFI_COMM_MASK				PIO_PB14_IDX
#define WIFI_COMM_ATTR				PIO_IT_RISE_EDGE

/* Provision button */
#define PUSH_BUTTON_ID                 ID_PIOB
#define PUSH_BUTTON_PIO                PIOB
#define PUSH_BUTTON_PIN_MSK            PIO_PB2
#define PUSH_BUTTON_ATTR               PIO_PULLUP | PIO_DEBOUNCE | PIO_IT_RISE_EDGE

/** SPI MISO pin definition. */
#define SPI_MISO_GPIO             (PIO_PA12_IDX)
#define SPI_MISO_FLAGS			  (PIO_PERIPH_A | PIO_DEFAULT)
/** SPI MOSI pin definition. */
#define SPI_MOSI_GPIO             (PIO_PA13_IDX)
#define SPI_MOSI_FLAGS			  (PIO_PERIPH_A | PIO_DEFAULT)
/** SPI SPCK pin definition. */
#define SPI_SPCK_GPIO             (PIO_PA14_IDX)
#define SPI_SPCK_FLAGS			  (PIO_PERIPH_A | PIO_DEFAULT)
/** SPI chip select 0 pin definition. (Only one configuration is possible) */
#define SPI_NPCS0_GPIO            (PIO_PA11_IDX)
#define SPI_NPCS0_FLAGS           (PIO_PERIPH_A | PIO_DEFAULT)

/* Chip select. */
#define SPI_CHIP_SEL 0
#define SPI_CHIP_PCS spi_get_pcs(SPI_CHIP_SEL)
/* Clock polarity. */
#define SPI_CLK_POLARITY 0
/* Clock phase. */
#define SPI_CLK_PHASE 0

#define wifi_spi_handler   SPI_Handler

volatile char input_line_wifi[1000];
volatile uint32_t input_pos_wifi;
volatile bool g_b_prov_button;
volatile bool g_b_success_received;

volatile uint32_t gs_ul_transfer_index;
volatile uint32_t gs_ul_transfer_length;

void process_incoming_byte_wifi(uint8_t in_byte);
void wifi_command_response_handler(uint32_t ul_id, uint32_t ul_mask);
void process_data_wifi(void);
void wifi_provision_handler(uint32_t ul_id, uint32_t ul_mask);
void configure_usart_wifi(void);
void configure_wifi_comm_pin(void);
void configure_wifi_provision_pin(void);
void configure_spi(void);
void spi_peripheral_initialize(void);
void prepare_spi_transfer(void);
void write_wifi_command(char* comm, uint8_t cnt);
void write_image_to_web(void);

#endif /* WIFI_H_ */