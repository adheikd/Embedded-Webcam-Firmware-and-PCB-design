/**
 * \file
 *
 * \brief User board initialization template
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include <asf.h>
#include <board.h>
#include <conf_board.h>

void board_init(void)
{
	/* This function is meant to contain board-specific initialization code
	 * for, e.g., the I/O pins. The initialization can rely on application-
	 * specific board configuration, found in conf_board.h.
	 */
	ioport_init();
	
	/* Set WiFi reset pin output */
	ioport_set_pin_dir(WIFI_RESET, IOPORT_DIR_OUTPUT);
	ioport_set_pin_level(WIFI_RESET, true);
	
	/* Set WiFi network pin and websocket client pin input */
	ioport_set_pin_dir(WIFI_NETWORK, IOPORT_DIR_INPUT);
	ioport_set_pin_dir(WIFI_CLIENTS, IOPORT_DIR_INPUT);
	
}
