/*
 * wifi.h
 *
 * Created: 2/22/2023 11:19:00 AM
 *  Author: ece-lab3
 */ 


#ifndef WIFI_H_
#define WIFI_H_

#include <asf.h>

#define BOARD_ID_USART           ID_USART0
#define BOARD_USART              USART0
#define BOARD_USART_BAUDRATE     115200
#define USART_Handler            USART0_Handler
#define USART_IRQn               USART0_IRQn 

#define ALL_INTERRUPT_MASK 0xffffffff

#define PIN_USART1_RXD {PIO_PA21A_RXD1, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_DEFAULT}
#define PIN_USART1_RXD_IDX (PIO_PA21_IDX)
#define PIN_USART1_RXD_FLAGS (PIO_PERIPH_A | PIO_DEFAULT)

#define PIN_USART1_TXD {PIO_PA22A_TXD1, PIOA, PIO_PERIPH_A, PIO_DEFAULT}
#define PIN_USART1_TXD_IDX (PIO_PA22_IDX)
#define PIN_USART1_TXD_FLAG (PIO_PERIPH_A | PIO_DEFAULT)

#define WIFI_COMM_PIN        PIO_PA23
#define WIFI_COMM_PIN_MSK    PIO_PA23_IDX
#define WIFI_COMM_PIO        PIOA
#define WIFI_COMM_ID         ID_PIOA
#define WIFI_COMM_ATTR       PIO_IT_RISE_EDGE

volatile char input_line_wifi[1000];
volatile uint32_t input_pos_wifi;

void configure_usart(void);


#endif /* WIFI_H_ */