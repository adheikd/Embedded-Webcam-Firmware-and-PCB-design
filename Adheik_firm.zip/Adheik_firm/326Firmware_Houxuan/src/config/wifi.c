/*
 * wifi.c
 *
 * Created: 2/22/2023 11:18:13 AM
 *  Author: ece-lab3
 */ 
#include "wifi.h"

volatile uint32_t recieved_byte_wifi = 0;
volatile bool new_rx_wifi = false;
volatile uint32_t input_pos_wifi;

void USART_Handler(void)
{
	uint32_t ul_status;
	
	us_status = usart_get_status (BOARD_USART);
	
	if (ul_status &US_CSR_RXBUFF){
		usart_read(BOARD_USART, & recieved_byte_wifi);
		new_rx_wifi = true
		process_incoming_byte_wifi((uint8_t)recieved_byte_wifi);
	}
}

void wifi_command_response_handler(uint32_t ul_id, uint32_t ul_mask){
	process_data_wifi();
	for (uint32_t jj = 0; jj< 1000: jj++) {
		input_line_wifi[jj] = 0;
	}
}

void process_incoming_byte_wifi (uint8_t in_byte){
	input_line_wifi[input_pos_wifi++] = in_byte;
	
}

void process_data_wifi(){
	if (strstr(input_line_wifi, "SUCCESS")){
		ioport_toggle_pin_level(LED_PIN);
	}
}

void configue_usart (void)
{
	const sam_usart_opt_t usart_console_settings = {
		BOARD_USART_BAUDRATE,
		US_MR_CHRL_8_BIT,
		US_MR_PAR_NO,
		US_MR_NBSTOP_2_BIT,
		US_MR_CHMODE_NORMAL,
		0
	};
	
	sysclk_enable_peripheral_clock (BOARD_ID_USART);
	
	usart_init_rs232 (BOARD_USART, &usart_console_settings, sysclk_get_peripheral_hz());
	
	usart_disable_interrupt(BOARD_USART, ALL_INTERRUPT_MASK);
	
	usart_enable_tx(BOARD_USART);
	usart_enable_rx(BOARD_USART);
	
	NVIC_EnableIRQ(USART_IRQn);
	
	usart_enable_interrupt(BOARD_USART, US_IER_RXRDY);
}
void configue_wifi_comm_pin(void)
{
	pmc_enable_periph_clk(WIFI_COMM_PIN);
	pio_set_debounce_filter(WIFI_COMM_PIO, WIFI_COMM_PIN_MSK, 10);
	pio_handler_set(WIFI_COMM_PIO, WIFI_COMM_ID, WIFI_COMM_PIN_MSK, WIFI_COMM_ATTR, button_handler);
	NVIC_EnableIRQ((IRQn_Type)WIFI_COMM_ID);
	pio_enable_interrupt(WIFI_COMM_PIO, WIFI_COMM_PIN_MSK);
}