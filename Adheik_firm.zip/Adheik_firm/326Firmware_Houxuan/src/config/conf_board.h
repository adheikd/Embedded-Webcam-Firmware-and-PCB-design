/**
 * \file
 *
 * \brief User board configuration template
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#ifndef CONF_BOARD_H
#define CONF_BOARD_H

#define WIFI_RESET  PIO_PB0_IDX

/* WiFi gpios */
#define WIFI_NETWORK     PIO_PA0_IDX
#define WIFI_CLIENTS     PIO_PA1_IDX

/** SPI base address for SPI slave mode, (on different board) */
#define SPI_SLAVE_BASE       SPI

/* Camera defines */

#endif // CONF_BOARD_H
